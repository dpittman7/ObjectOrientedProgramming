//
// Created by deant on 3/12/2020.
//

#include "Shapes.h"

double Shapes::area() {

}

double Shapes::perimeter() {

    return 0;
}

void Shapes::setlength() {

}


double Shapes::getlength()
{

}

Shapes::Shapes() {

}

Shapes::Shapes(double input)
{

}

void Shapes::printData() {

}
