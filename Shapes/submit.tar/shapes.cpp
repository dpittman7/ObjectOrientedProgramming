//
// Created by deant on 3/12/2020.
//

#include "shapes.h"

double shapes::area() {

}

double shapes::perimeter() {

    return 0;
}

void shapes::setlength() {

}


double shapes::getlength()
{

}

shapes::shapes() {

}

shapes::shapes(double input)
{

}

void shapes::printData() {

}
